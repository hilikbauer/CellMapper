package com.example.cellmapper

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.CellIdentityNr
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellSignalStrengthNr
import android.telephony.TelephonyManager
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.ScaleBarOverlay
import org.osmdroid.views.overlay.gestures.RotationGestureOverlay
import java.util.Locale
import kotlin.math.*

const val CELL = 12.0 // גודל תא במפת החום, במטרים

class Sample(val lat: Double, val lon: Double, val x: Double, val y: Double, val dbm: Int)

class Tower(val key: String, val color: Int) {
    val samples = ArrayList<Sample>()
    var best = -200
    var hasEst = false
    var estLat = 0.0
    var estLon = 0.0
}

class Heat(val lat: Double, val lon: Double, var dbm: Double, var n: Int)

// אדום = קליטה חלשה, ירוק = קליטה חזקה
fun qColor(dbm: Double, alpha: Int = 170): Int {
    val t = ((dbm + 115.0) / 40.0).coerceIn(0.0, 1.0)
    return Color.HSVToColor(alpha, floatArrayOf((120.0 * t).toFloat(), 0.9f, 0.95f))
}

class DataOverlay(
    private val towers: () -> Collection<Tower>,
    private val heat: () -> Collection<Heat>,
    private val me: () -> GeoPoint?,
    private val bearing: () -> Float?
) : Overlay() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pt = Point()
    private val a = Point()
    private val b = Point()
    private val path = Path()

    override fun draw(c: Canvas, osmv: MapView, shadow: Boolean) {
        if (shadow) return
        val proj = osmv.projection
        val rot = osmv.mapOrientation

        // מפת חום
        val cells = heat()
        if (cells.isNotEmpty()) {
            val ctr = osmv.mapCenter
            proj.toPixels(GeoPoint(ctr.latitude, ctr.longitude), a)
            proj.toPixels(GeoPoint(ctr.latitude + 100.0 / 110540.0, ctr.longitude), b)
            val pm = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()) / 100.0
            val r = max(5f, (CELL * 0.75 * pm).toFloat())
            p.style = Paint.Style.FILL
            for (h in cells) {
                proj.toPixels(GeoPoint(h.lat, h.lon), pt)
                p.color = qColor(h.dbm)
                c.drawCircle(pt.x.toFloat(), pt.y.toFloat(), r, p)
            }
        }

        // אנטנות
        for (t in towers()) {
            if (!t.hasEst) continue
            proj.toPixels(GeoPoint(t.estLat, t.estLon), pt)
            val x = pt.x.toFloat(); val y = pt.y.toFloat()
            p.style = Paint.Style.FILL
            p.color = Color.WHITE; c.drawCircle(x, y, 30f, p)
            p.color = t.color; c.drawCircle(x, y, 25f, p)
            path.reset()
            path.moveTo(x, y - 15f); path.lineTo(x - 11f, y + 12f); path.lineTo(x + 11f, y + 12f); path.close()
            p.color = Color.WHITE; c.drawPath(path, p)
            c.save()
            c.rotate(-rot, x, y)
            p.textSize = 30f
            p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = Color.WHITE
            c.drawText(t.key, x + 38f, y + 10f, p)
            p.style = Paint.Style.FILL; p.color = Color.BLACK
            c.drawText(t.key, x + 38f, y + 10f, p)
            c.restore()
        }

        // המיקום שלי
        me()?.let {
            proj.toPixels(it, pt)
            val x = pt.x.toFloat(); val y = pt.y.toFloat()
            p.style = Paint.Style.FILL
            val br = bearing()
            if (br != null) {
                c.save()
                c.rotate(br, x, y)
                path.reset()
                path.moveTo(x, y - 40f); path.lineTo(x - 15f, y - 12f); path.lineTo(x + 15f, y - 12f); path.close()
                p.color = Color.rgb(0, 90, 220); c.drawPath(path, p)
                c.restore()
            }
            p.color = Color.WHITE; c.drawCircle(x, y, 19f, p)
            p.color = Color.rgb(0, 120, 255); c.drawCircle(x, y, 14f, p)
        }
    }
}

class MainActivity : Activity() {
    private val towers = LinkedHashMap<String, Tower>()
    private val heat = HashMap<Long, Heat>()
    private val palette = intArrayOf(
        Color.rgb(90, 60, 200), Color.rgb(30, 90, 180), Color.rgb(160, 60, 190),
        Color.rgb(0, 130, 140), Color.rgb(60, 60, 60), Color.rgb(150, 70, 20)
    )
    private var lat0 = Double.NaN
    private var lon0 = 0.0
    private var loc: Location? = null
    private var me: GeoPoint? = null
    private var meBearing: Float? = null
    private var running = false
    private var centered = false
    private var follow = true
    private var headingUp = false
    private var lastSave = 0L
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var tm: TelephonyManager
    private lateinit var lm: LocationManager
    private lateinit var status: TextView
    private lateinit var list: TextView
    private lateinit var map: MapView
    private lateinit var toggle: Button
    private lateinit var centerBtn: Button
    private lateinit var orientBtn: Button

    private val locListener = object : LocationListener {
        override fun onLocationChanged(l: Location) { loc = l }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, s: Int, e: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            poll()
            handler.postDelayed(this, 2000)
        }
    }

    private fun legendText(): SpannableString {
        val blocks = "■■■■■■"
        val s = SpannableString("קליטה: $blocks  אדום = חלשה, ירוק = חזקה")
        val start = s.toString().indexOf(blocks)
        for (i in 0 until 6) {
            s.setSpan(ForegroundColorSpan(qColor(-115.0 + 40.0 * i / 5, 255)), start + i, start + i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return s
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osm", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = "CellMapper/2.0 (https://github.com/hilikbauer/CellMapper)"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        lm = getSystemService(LOCATION_SERVICE) as LocationManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18, 22, 28))
            setPadding(24, 56, 24, 24)
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            text = "גרסה 5 - לחץ \"התחל מדידה\" והסתובב סביב האזור"
        }
        val legend = TextView(this).apply { textSize = 12f; setTextColor(Color.LTGRAY); text = legendText() }

        map = MapView(this).apply {
            setTileSource(object : OnlineTileSourceBase("EsriStreet", 0, 19, 256, "", arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/"), "Tiles © Esri") {
                override fun getTileURLString(pMapTileIndex: Long): String =
                    baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" + MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex)
            })
            setMultiTouchControls(true)
            controller.setZoom(3.0)
            val rotation = RotationGestureOverlay(this)
            rotation.isEnabled = true
            overlays.add(rotation)
            overlays.add(DataOverlay({ towers.values }, { heat.values }, { me }, { meBearing }))
            overlays.add(ScaleBarOverlay(this))
            overlays.add(CopyrightOverlay(context))
            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_MOVE && follow) { follow = false; updateButtons() }
                false
            }
        }
        list = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 13f }
        val scroll = ScrollView(this).apply { addView(list) }

        toggle = Button(this).apply { text = "התחל מדידה"; setOnClickListener { if (running) stop() else start() } }
        val clear = Button(this).apply { text = "נקה"; setOnClickListener { clearAll() } }
        val export = Button(this).apply { text = "ייצוא CSV"; setOnClickListener { export() } }
        centerBtn = Button(this).apply {
            setOnClickListener {
                follow = true
                me?.let {
                    map.controller.setZoom(max(map.zoomLevelDouble, 17.0))
                    map.controller.animateTo(it)
                }
                updateButtons()
            }
        }
        orientBtn = Button(this).apply {
            setOnClickListener {
                headingUp = !headingUp
                if (!headingUp) map.mapOrientation = 0f
                updateButtons()
            }
        }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(toggle, lp); addView(clear, lp); addView(export, lp) }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(centerBtn, lp); addView(orientBtn, lp) }

        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        root.addView(status, LinearLayout.LayoutParams(mp, wc))
        root.addView(legend, LinearLayout.LayoutParams(mp, wc))
        root.addView(map, LinearLayout.LayoutParams(mp, 0, 1f))
        root.addView(scroll, LinearLayout.LayoutParams(mp, 0, 0.45f))
        root.addView(row1, LinearLayout.LayoutParams(mp, wc))
        root.addView(row2, LinearLayout.LayoutParams(mp, wc))
        setContentView(root)
        updateButtons()

        load()
        if (!lat0.isNaN()) {
            map.controller.setZoom(16.0)
            map.controller.setCenter(GeoPoint(lat0, lon0))
            centered = true
            status.text = "נטענו נתונים שמורים (${heat.size} אזורים, ${towers.size} אנטנות)"
        }
        refresh()
    }

    private fun updateButtons() {
        centerBtn.text = if (follow) "עוקב אחריי ✓" else "מרכז עליי"
        orientBtn.text = if (headingUp) "כיוון: הליכה" else "כיוון: צפון"
    }

    override fun onResume() { super.onResume(); map.onResume() }

    override fun onPause() {
        save()
        map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        stop()
        super.onDestroy()
    }

    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasLocationPermission()) start() else status.text = "נדרשת הרשאת מיקום כדי למדוד אנטנות"
    }

    @SuppressLint("MissingPermission")
    private fun start() {
        if (!hasLocationPermission()) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE), 1)
            return
        }
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        running = true
        toggle.text = "עצור"
        status.text = "ממתין לאות GPS…"
        handler.post(tick)
    }

    private fun stop() {
        if (running) {
            try { lm.removeUpdates(locListener) } catch (_: Exception) {}
            save()
        }
        running = false
        handler.removeCallbacks(tick)
        if (::toggle.isInitialized) toggle.text = "התחל מדידה"
    }

    @SuppressLint("MissingPermission")
    private fun poll() {
        try {
            tm.requestCellInfoUpdate(mainExecutor, object : TelephonyManager.CellInfoCallback() {
                override fun onCellInfo(cellInfo: MutableList<CellInfo>) { handle(cellInfo) }
            })
        } catch (e: SecurityException) {
            status.text = "חסרות הרשאות לקריאת נתוני רשת"
        }
    }

    private fun parse(ci: CellInfo): Pair<String, Int>? {
        val key: String
        val dbm: Int
        when {
            ci is CellInfoLte -> {
                val i = ci.cellIdentity
                if (i.ci == Int.MAX_VALUE) return null
                key = "LTE ${i.mccString}-${i.mncString} eNB ${i.ci shr 8}"
                dbm = ci.cellSignalStrength.dbm
            }
            ci is CellInfoNr -> {
                val i = ci.cellIdentity as CellIdentityNr
                if (i.nci == Long.MAX_VALUE) return null
                key = "5G ${i.mccString}-${i.mncString} cell ${i.nci}"
                dbm = (ci.cellSignalStrength as CellSignalStrengthNr).dbm
            }
            ci is CellInfoWcdma -> {
                val i = ci.cellIdentity
                if (i.cid == Int.MAX_VALUE) return null
                key = "3G ${i.mccString}-${i.mncString} cell ${i.cid}"
                dbm = ci.cellSignalStrength.dbm
            }
            ci is CellInfoGsm -> {
                val i = ci.cellIdentity
                if (i.cid == Int.MAX_VALUE) return null
                key = "2G ${i.mccString}-${i.mncString} cell ${i.cid}"
                dbm = ci.cellSignalStrength.dbm
            }
            else -> return null
        }
        if (dbm !in -140..-30) return null
        return Pair(key, dbm)
    }

    private fun toX(lat: Double, lon: Double) = (lon - lon0) * 111320.0 * cos(Math.toRadians(lat0))
    private fun toY(lat: Double) = (lat - lat0) * 110540.0

    // מוסיף מדידת קליטה לתא במפת החום (ממוצע נע)
    private fun addHeat(lat: Double, lon: Double, dbm: Double, count: Int) {
        if (lat0.isNaN()) { lat0 = lat; lon0 = lon }
        val gx = floor(toX(lat, lon) / CELL).toLong()
        val gy = floor(toY(lat) / CELL).toLong()
        val key = (gx + 500_000L) * 1_000_000L + (gy + 500_000L)
        val h = heat[key]
        if (h == null) {
            val cLat = lat0 + (gy + 0.5) * CELL / 110540.0
            val cLon = lon0 + (gx + 0.5) * CELL / (111320.0 * cos(Math.toRadians(lat0)))
            heat[key] = Heat(cLat, cLon, dbm, count.coerceAtLeast(1))
        } else {
            h.dbm = (h.dbm * h.n + dbm) / (h.n + 1)
            h.n = min(h.n + 1, 10)
        }
    }

    private fun handle(cells: List<CellInfo>) {
        if (!running) return
        val l = loc
        if (l == null) { status.text = "ממתין לאות GPS…"; return }
        if (System.currentTimeMillis() - l.time > 10_000 || l.accuracy > 40f) {
            status.text = "ממתין לדיוק GPS טוב יותר (${l.accuracy.toInt()} מ׳)"
            return
        }
        if (lat0.isNaN()) { lat0 = l.latitude; lon0 = l.longitude }
        val x = toX(l.latitude, l.longitude)
        val y = toY(l.latitude)

        val now = HashMap<String, Int>()
        var regBest = -999
        for (ci in cells) {
            val (k, d) = parse(ci) ?: continue
            if (d > (now[k] ?: -999)) now[k] = d
            if (ci.isRegistered && d > regBest) regBest = d
        }

        // איכות הקליטה במקום הזה: התא המשרת, או החזק ביותר
        val reception = if (now.isEmpty()) -125
        else if (regBest > -999) regBest else now.values.max()
        addHeat(l.latitude, l.longitude, reception.toDouble(), 1)

        var added = false
        for ((k, d) in now) {
            val t = towers.getOrPut(k) { Tower(k, palette[towers.size % palette.size]) }
            val last = t.samples.lastOrNull()
            if (last == null || hypot(last.x - x, last.y - y) >= 5.0) {
                t.samples.add(Sample(l.latitude, l.longitude, x, y, d))
                estimate(t)
                added = true
            }
            if (d > t.best) t.best = d
        }

        val g = GeoPoint(l.latitude, l.longitude)
        me = g
        meBearing = if (l.hasBearing() && l.speed > 0.8f) l.bearing else null
        if (headingUp && l.hasBearing() && l.speed > 1f) map.mapOrientation = -l.bearing
        if (!centered) {
            map.controller.setZoom(18.0); map.controller.setCenter(g); centered = true
        } else if (follow) {
            map.controller.animateTo(g)
        }
        if (System.currentTimeMillis() - lastSave > 15_000 && (added || heat.isNotEmpty())) save()

        val q = when {
            now.isEmpty() -> "אין קליטה"
            reception >= -85 -> "טובה"
            reception >= -100 -> "בינונית"
            reception >= -110 -> "חלשה"
            else -> "גרועה"
        }
        status.text = if (now.isEmpty()) "אין קליטה כאן | GPS ±${l.accuracy.toInt()} מ׳"
        else "קליטה: $reception dBm ($q) | ${now.size} תאים | GPS ±${l.accuracy.toInt()} מ׳"
        refresh()
    }

    // ממוצע משוקלל של הדגימות החזקות ביותר (משקל לפי עוצמת אות לינארית)
    private fun estimate(t: Tower) {
        if (t.samples.size < 5) { t.hasEst = false; return }
        val sorted = t.samples.sortedByDescending { it.dbm }
        val top = sorted.take(max(3, (sorted.size * 0.3).toInt()))
        val best = top[0].dbm
        var sw = 0.0; var sla = 0.0; var slo = 0.0
        for (s in top) {
            val w = 10.0.pow((s.dbm - best) / 10.0)
            sw += w; sla += w * s.lat; slo += w * s.lon
        }
        t.estLat = sla / sw
        t.estLon = slo / sw
        t.hasEst = true
    }

    private fun refresh() {
        map.invalidate()
        list.text = towers.values.sortedByDescending { it.samples.size }.joinToString("\n\n") { t ->
            val pos = if (t.hasEst) String.format(Locale.US, "מיקום משוער: %.5f, %.5f", t.estLat, t.estLon)
            else "צריך עוד דגימות (לפחות 5, מנקודות שונות)"
            "▲ ${t.key}\n   דגימות: ${t.samples.size} | הכי חזק: ${t.best} dBm\n   $pos"
        }
    }

    private fun save() {
        lastSave = System.currentTimeMillis()
        val sb = StringBuilder()
        for (t in towers.values) for (s in t.samples)
            sb.append(t.key).append('|').append(s.lat).append('|').append(s.lon).append('|').append(s.dbm).append('\n')
        val hb = StringBuilder()
        for (h in heat.values) hb.append(h.lat).append('|').append(h.lon).append('|').append(h.dbm).append('\n')
        getSharedPreferences("data", MODE_PRIVATE).edit()
            .putString("samples", sb.toString())
            .putString("heat", hb.toString())
            .apply()
    }

    private fun load() {
        val prefs = getSharedPreferences("data", MODE_PRIVATE)
        val txt = prefs.getString("samples", null)
        if (txt != null) for (line in txt.lineSequence()) {
            val a = line.split('|')
            if (a.size != 4) continue
            val lat = a[1].toDoubleOrNull() ?: continue
            val lon = a[2].toDoubleOrNull() ?: continue
            val dbm = a[3].toIntOrNull() ?: continue
            if (lat0.isNaN()) { lat0 = lat; lon0 = lon }
            val t = towers.getOrPut(a[0]) { Tower(a[0], palette[towers.size % palette.size]) }
            t.samples.add(Sample(lat, lon, toX(lat, lon), toY(lat), dbm))
            if (dbm > t.best) t.best = dbm
        }
        towers.values.forEach { estimate(it) }
        val ht = prefs.getString("heat", null)
        if (ht != null) for (line in ht.lineSequence()) {
            val a = line.split('|')
            if (a.size != 3) continue
            val lat = a[0].toDoubleOrNull() ?: continue
            val lon = a[1].toDoubleOrNull() ?: continue
            val dbm = a[2].toDoubleOrNull() ?: continue
            addHeat(lat, lon, dbm, 3)
        }
    }

    private fun clearAll() {
        towers.clear()
        heat.clear()
        lat0 = Double.NaN
        me = null
        getSharedPreferences("data", MODE_PRIVATE).edit().remove("samples").remove("heat").apply()
        refresh()
    }

    private fun export() {
        val sb = StringBuilder("tower,lat,lon,dbm,type\n")
        for (t in towers.values) {
            for (s in t.samples) sb.append("\"${t.key}\",${s.lat},${s.lon},${s.dbm},sample\n")
            if (t.hasEst) sb.append("\"${t.key}\",${t.estLat},${t.estLon},,estimate\n")
        }
        for (h in heat.values) sb.append("-,${h.lat},${h.lon},${"%.1f".format(Locale.US, h.dbm)},heat\n")
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, sb.toString().take(400_000))
        }
        startActivity(Intent.createChooser(i, "ייצוא CSV"))
    }
}
